<TS language="eo" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Dekstre-klaku por redakti adreson aŭ etikedon</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Krei novan adreson</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Nova</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Kopii elektitan adreson al la tondejo</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Kopii</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>&amp;Fermi</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Forigi la elektitan adreson el la listo</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Eksporti la datumojn el la aktuala langeto al dosiero</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Eksporti</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Forigi</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Dialogo pri pasfrazo</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Enigu pasfrazon</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Nova pasfrazo</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Ripetu la novan pasfrazon</translation>
    </message>
    </context>
<context>
    <name>BanTableModel</name>
    </context>
<context>
    <name>WochainGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>Subskribi &amp;mesaĝon...</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Sinkronigante kun reto...</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Superrigardo</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Nodo</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Vidigi ĝeneralan superrigardon de la monujo</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Transakcioj</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Esplori historion de transakcioj</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Eliri</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Eliri la aplikaĵon</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Pri &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Vidigi informojn pri Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Agordoj...</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>Ĉifri &amp;Monujon...</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;Krei sekurkopion de la monujo...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>Ŝanĝi &amp;Pasfrazon...</translation>
    </message>
    <message>
        <source>&amp;Sending addresses...</source>
        <translation>&amp;Sendaj adresoj...</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses...</source>
        <translation>&amp;Ricevaj adresoj...</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>Malfermi &amp;URI-on...</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>Reindeksado de blokoj sur disko...</translation>
    </message>
    <message>
        <source>Send coins to a Wochain address</source>
        <translation>Sendi monon al Bitmon-adreso</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Krei alilokan sekurkopion de monujo</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Ŝanĝi la pasfrazon por ĉifri la monujon</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>Sen&amp;cimiga fenestro</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>Malfermi konzolon de sencimigo kaj diagnozo</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>&amp;Kontroli mesaĝon...</translation>
    </message>
    <message>
        <source>Wochain</source>
        <translation>Bitmono</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Monujo</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Sendi</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation>&amp;Ricevi</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Montri / Kaŝi</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>Montri aŭ kaŝi la ĉefan fenestron</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>Ĉifri la privatajn ŝlosilojn de via monujo</translation>
    </message>
    <message>
        <source>Sign messages with your Wochain addresses to prove you own them</source>
        <translation>Subskribi mesaĝojn per via Bitmon-adresoj por pravigi, ke vi estas la posedanto</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Wochain addresses</source>
        <translation>Kontroli mesaĝojn por kontroli ĉu ili estas subskribitaj per specifaj Bitmon-adresoj</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Dosiero</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Agordoj</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Helpo</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Langeto-breto</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and wochain: URIs)</source>
        <translation>Peti pagon (kreas QR-kodojn kaj URI-ojn kun prefikso wochain:)</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation>Vidigi la liston de uzitaj sendaj adresoj kaj etikedoj</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation>Vidigi la liston de uzitaj ricevaj adresoj kaj etikedoj</translation>
    </message>
    <message>
        <source>Open a wochain: URI or payment request</source>
        <translation>Malfermi wochain:-URI-on aŭ pagpeton</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>&amp;Komandliniaj agordaĵoj</translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>mankas %1</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>Lasta ricevita bloko kreiĝis antaŭ %1.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>Transakcioj por tio ankoraŭ ne videblas.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Eraro</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Averto</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Informoj</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Ĝisdata</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Ĝisdatigante...</translation>
    </message>
    <message>
        <source>Date: %1
</source>
        <translation>Dato: %1
</translation>
    </message>
    <message>
        <source>Amount: %1
</source>
        <translation>Sumo: %1
</translation>
    </message>
    <message>
        <source>Type: %1
</source>
        <translation>Tipo: %1
</translation>
    </message>
    <message>
        <source>Label: %1
</source>
        <translation>Etikedo: %1
</translation>
    </message>
    <message>
        <source>Address: %1
</source>
        <translation>Adreso: %1
</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Sendita transakcio</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Envenanta transakcio</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Monujo estas &lt;b&gt;ĉifrita&lt;/b&gt; kaj aktuale &lt;b&gt;malŝlosita&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Monujo estas &lt;b&gt;ĉifrita&lt;/b&gt; kaj aktuale &lt;b&gt;ŝlosita&lt;/b&gt;</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Quantity:</source>
        <translation>Kvanto:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Bajtoj:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Sumo:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Krompago:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Polvo:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Post krompago:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Restmono:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation>(mal)elekti ĉion</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation>Arboreĝimo</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>Listreĝimo</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Sumo</translation>
    </message>
    <message>
        <source>Received with label</source>
        <translation>Ricevita kun etikedo</translation>
    </message>
    <message>
        <source>Received with address</source>
        <translation>Ricevita kun adreso</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Dato</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>Konfirmoj</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Konfirmita</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Redakti Adreson</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Etikedo</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation>La etikedo ligita al tiu ĉi adreslistero</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation>La adreso ligita al tiu ĉi adreslistero. Eblas modifi tion nur por sendaj adresoj.</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Adreso</translation>
    </message>
    </context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>Kreiĝos nova dosierujo por la datumoj.</translation>
    </message>
    <message>
        <source>name</source>
        <translation>nomo</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation>Tiu dosierujo jam ekzistas. Aldonu %1 si vi volas krei novan dosierujon ĉi tie.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation>Vojo jam ekzistas, kaj ne estas dosierujo.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>Ne eblas krei dosierujon por datumoj ĉi tie.</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation>versio</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>Komandliniaj agordaĵoj</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>Uzado:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>komandliniaj agordaĵoj</translation>
    </message>
    <message>
        <source>UI Options:</source>
        <translation>Uzantinterfaco ebloj:</translation>
    </message>
    </context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>Bonvenon</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>Uzi la defaŭltan dosierujon por datumoj</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>Uzi alian dosierujon por datumoj:</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Eraro</translation>
    </message>
    <message numerus="yes">
        <source>%n GB of free space available</source>
        <translation><numerusform>%n gigabajto de libera loko disponeble</numerusform><numerusform>%n gigabajtoj de libera loko disponebla.</numerusform></translation>
    </message>
    </context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation>Formularo</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Horo de la lasta bloko</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>Malfermi URI-on</translation>
    </message>
    <message>
        <source>Open payment request from URI or file</source>
        <translation>Malfermi pagpeton el URI aŭ dosiero</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation>URI:</translation>
    </message>
    <message>
        <source>Select payment request file</source>
        <translation>Elektu la dosieron de la pagpeto</translation>
    </message>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Agordaĵoj</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>Ĉ&amp;efa</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation>Dosiergrando de &amp;datumbasa kaŝmemoro</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <source>Accept connections from outside</source>
        <translation>Akcepti konektojn el ekstere</translation>
    </message>
    <message>
        <source>Allow incoming connections</source>
        <translation>Permesi envenantajn konektojn</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation>Reagordi ĉion al defaŭlataj valoroj.</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation>&amp;Rekomenci agordadon</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;Reto</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>Monujo</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation>Fakulo</translation>
    </message>
    <message>
        <source>Automatically open the Wochain client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Aŭtomate malfermi la kursilan pordon por Bitmono. Tio funkcias nur se via kursilo havas la UPnP-funkcion, kaj se tiu ĉi estas ŝaltita.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>Mapigi pordon per &amp;UPnP</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>Prokurila &amp;IP:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;Pordo:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>la pordo de la prokurilo (ekz. 9050)</translation>
    </message>
    <message>
        <source>IPv4</source>
        <translation>IPv4</translation>
    </message>
    <message>
        <source>IPv6</source>
        <translation>IPv6</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Fenestro</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Montri nur sistempletan piktogramon post minimumigo de la fenestro.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;Minimumigi al la sistempleto anstataŭ al la taskopleto</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>M&amp;inimumigi je fermo</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>&amp;Aspekto</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>&amp;Lingvo de la fasado:</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>&amp;Unuo por vidigi sumojn:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Elekti la defaŭltan manieron por montri bitmonajn sumojn en la interfaco, kaj kiam vi sendos bitmonon.</translation>
    </message>
    <message>
        <source>Whether to show coin control features or not.</source>
        <translation>Ĉu montri detalan adres-regilon, aŭ ne.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Bone</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Nuligi</translation>
    </message>
    <message>
        <source>default</source>
        <translation>defaŭlta</translation>
    </message>
    <message>
        <source>none</source>
        <translation>neniu</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>Konfirmi reŝargo de agordoj</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>La prokurila adreso estas malvalida.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Formularo</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Wochain network after a connection is established, but this process has not completed yet.</source>
        <translation>Eblas, ke la informoj videblaj ĉi tie estas eksdataj. Via monujo aŭtomate sinkoniĝas kun la bitmona reto kiam ili konektiĝas, sed tiu procezo ankoraŭ ne finfariĝis.</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation>via aktuala elspezebla saldo</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation>la sumo de transakcioj ankoraŭ ne konfirmitaj, kiuj ankoraŭ ne elspezeblas</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>Nematura:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>Minita saldo, kiu ankoraŭ ne maturiĝis</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation>Saldoj</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>Totalo:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>via aktuala totala saldo</translation>
    </message>
    <message>
        <source>Spendable:</source>
        <translation>Elspezebla:</translation>
    </message>
    <message>
        <source>Recent transactions</source>
        <translation>Lastaj transakcioj</translation>
    </message>
    </context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>User Agent</source>
        <translation>Uzanto Agento</translation>
    </message>
    </context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>Sumo</translation>
    </message>
    <message>
        <source>%1 h</source>
        <translation>%1 h</translation>
    </message>
    <message>
        <source>%1 m</source>
        <translation>%1 m</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Neniu</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>neaplikebla</translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 kaj %2</translation>
    </message>
    </context>
<context>
    <name>QObject::QObject</name>
    </context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>N/A</source>
        <translation>neaplikebla</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>Versio de kliento</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Informoj</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>Sencimiga fenestro</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Ĝenerala</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>Horo de lanĉo</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Reto</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nomo</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>Nombro de konektoj</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>Blokĉeno</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>Aktuala nombro de blokoj</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>Ricevita</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Sendita</translation>
    </message>
    <message>
        <source>&amp;Peers</source>
        <translation>&amp;Samuloj</translation>
    </message>
    <message>
        <source>Banned peers</source>
        <translation>Malpermesita samuloj.</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versio</translation>
    </message>
    <message>
        <source>User Agent</source>
        <translation>Uzanto Agento</translation>
    </message>
    <message>
        <source>Services</source>
        <translation>Servoj</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Horo de la lasta bloko</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Malfermi</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;Konzolo</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation>&amp;Reta Trafiko</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Forigi ĉion</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>Totaloj</translation>
    </message>
    <message>
        <source>In:</source>
        <translation>En:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation>El:</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>Sencimiga protokoldosiero</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>Malplenigi konzolon</translation>
    </message>
    <message>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>Uzu la sagojn supran kaj malsupran por esplori la historion, kaj &lt;b&gt;stir-L&lt;/b&gt; por malplenigi la ekranon.</translation>
    </message>
    <message>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>Tajpu &lt;b&gt;help&lt;/b&gt; por superrigardo de la disponeblaj komandoj.</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1 B</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 KB</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 GB</translation>
    </message>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>&amp;Kvanto:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Etikedo:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>&amp;Mesaĝo:</translation>
    </message>
    <message>
        <source>Reuse one of the previously used receiving addresses. Reusing addresses has security and privacy issues. Do not use this unless re-generating a payment request made before.</source>
        <translation>Reuzi unu el la jam uzitaj ricevaj adresoj. Reuzo de adresoj povas krei problemojn pri sekureco kaj privateco. Ne uzu tiun ĉi funkcion krom por rekrei antaŭe faritan pagopeton.</translation>
    </message>
    <message>
        <source>R&amp;euse an existing receiving address (not recommended)</source>
        <translation>R&amp;euzi ekzistantan ricevan adreson (malrekomendinda)</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Malplenigi ĉiujn kampojn de la formularo.</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Forigi</translation>
    </message>
    <message>
        <source>&amp;Request payment</source>
        <translation>&amp;Peti pagon</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Vidigi</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Forigi</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>QR-kodo</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation>Kopii &amp;URI</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>Kopii &amp;Adreson</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>&amp;Konservi Bildon...</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Sendi Bitmonon</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation>Monregaj Opcioj</translation>
    </message>
    <message>
        <source>Inputs...</source>
        <translation>Enigoj...</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>Nesufiĉa mono!</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Kvanto:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Bajtoj:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Sumo:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Krompago:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Post krompago:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Restmono:</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation>Krompago:</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Sendi samtempe al pluraj ricevantoj</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>Aldoni &amp;Ricevonton</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Malplenigi ĉiujn kampojn de la formularo.</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Polvo:</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>&amp;Forigi Ĉion</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Saldo:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Konfirmi la sendon</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>Ŝendi</translation>
    </message>
    </context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>&amp;Sumo:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>&amp;Ricevonto:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Etikedo:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Elektu la jam uzitan adreson</translation>
    </message>
    <message>
        <source>This is a normal payment.</source>
        <translation>Tio estas normala pago.</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Alglui adreson de tondejo</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation>Forigu ĉi tiun enskribon</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Mesaĝo:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation>Tajpu etikedon por tiu ĉi adreso por aldoni ĝin al la listo de uzitaj adresoj</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>Pagi Al:</translation>
    </message>
    <message>
        <source>Memo:</source>
        <translation>Memorando:</translation>
    </message>
    </context>
<context>
    <name>SendConfirmationDialog</name>
    </context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation>Ne sistemfermu ĝis ĉi tiu fenestro malaperas.</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Subskriboj - Subskribi / Kontroli mesaĝon</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>&amp;Subskribi Mesaĝon</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Elektu la jam uzitan adreson</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Alglui adreson de tondejo</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Tajpu la mesaĝon, kiun vi volas sendi, cîi tie</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Subskribo</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Kopii la aktualan subskribon al la tondejo</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Wochain address</source>
        <translation>Subskribi la mesaĝon por pravigi, ke vi estas la posedanto de tiu Bitmon-adreso</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>Subskribi &amp;Mesaĝon</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>Reagordigi ĉiujn prisubskribajn kampojn</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>&amp;Forigi Ĉion</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>&amp;Kontroli Mesaĝon</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Wochain address</source>
        <translation>Kontroli la mesaĝon por pravigi, ke ĝi ja estas subskribita per la specifa Bitmon-adreso</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>Kontroli &amp;Mesaĝon</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>Reagordigi ĉiujn prikontrolajn kampojn</translation>
    </message>
    </context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <source>KB/s</source>
        <translation>KB/s</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    </context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Tiu ĉi panelo montras detalan priskribon de la transakcio</translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    </context>
<context>
    <name>TransactionView</name>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    </context>
<context>
    <name>WalletView</name>
    </context>
<context>
    <name>wochain-core</name>
    <message>
        <source>Options:</source>
        <translation>Agordoj:</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Specifi dosieron por datumoj</translation>
    </message>
    <message>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>Konekti al nodo por ricevi adresojn de samtavolanoj, kaj malkonekti</translation>
    </message>
    <message>
        <source>Specify your own public address</source>
        <translation>Specifi vian propran publikan adreson</translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Akcepti komandojn JSON-RPC kaj el komandlinio</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Ruli fone kiel demono kaj akcepti komandojn</translation>
    </message>
    <message>
        <source>Wochain Core</source>
        <translation>Kerno de Bitmono</translation>
    </message>
    <message>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation>Bindi al donita adreso kaj ĉiam aŭskulti per ĝi. Uzu la formaton [gastigo]:pordo por IPv6</translation>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation>Plenumi komandon kiam monuja transakcio ŝanĝiĝas (%s en cmd anstataŭiĝas per TxID)</translation>
    </message>
    <message>
        <source>&lt;category&gt; can be:</source>
        <translation>&lt;category&gt; povas esti:</translation>
    </message>
    <message>
        <source>Block creation options:</source>
        <translation>Blok-kreaj agordaĵoj:</translation>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation>Difektita blokdatumbazo trovita</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>Ĉu vi volas rekonstrui la blokdatumbazon nun?</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>Eraro dum pravalorizado de blokdatumbazo</translation>
    </message>
    <message>
        <source>Error initializing wallet database environment %s!</source>
        <translation>Eraro dum pravalorizado de monuj-datumbaza ĉirkaŭaĵo %s!</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation>Eraro dum ŝargado de blokdatumbazo</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation>Eraro dum malfermado de blokdatumbazo</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>Eraro: restas malmulte da diskospaco!</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Ne sukcesis aŭskulti ajnan pordon. Uzu -listen=0 se tion vi volas.</translation>
    </message>
    <message>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation>Geneza bloko aŭ netrovita aŭ neĝusta. Ĉu eble la datadir de la reto malĝustas?</translation>
    </message>
    <message>
        <source>Invalid -onion address: '%s'</source>
        <translation>Nevalida -onion-adreso: '%s'</translation>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation>Nesufiĉa nombro de dosierpriskribiloj disponeblas.</translation>
    </message>
    <message>
        <source>Specify wallet file (within data directory)</source>
        <translation>Specifi monujan dosieron (ene de dosierujo por datumoj)</translation>
    </message>
    <message>
        <source>Verifying blocks...</source>
        <translation>Kontrolado de blokoj...</translation>
    </message>
    <message>
        <source>Verifying wallet...</source>
        <translation>Kontrolado de monujo...</translation>
    </message>
    <message>
        <source>Wallet %s resides outside data directory %s</source>
        <translation>Monujo %s troviĝas ekster la dosierujo por datumoj %s</translation>
    </message>
    <message>
        <source>Wallet options:</source>
        <translation>Monujaj opcioj:</translation>
    </message>
    <message>
        <source>Execute command when a relevant alert is received or we see a really long fork (%s in cmd is replaced by message)</source>
        <translation>Plenumi komandon kiam rilata alerto riceviĝas, aŭ kiam ni vidas tre longan forkon (%s en cms anstataŭiĝas per mesaĝo)</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Informoj</translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Sendi spurajn/sencimigajn informojn al la konzolo anstataŭ al dosiero debug.log</translation>
    </message>
    <message>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>Malpligrandigi la sencimigan protokol-dosieron kiam kliento lanĉiĝas (defaŭlte: 1 kiam mankas -debug)</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation>Subskriba transakcio fiaskis</translation>
    </message>
    <message>
        <source>This is experimental software.</source>
        <translation>ĝi estas eksperimenta programo</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>Transakcia sumo tro malgranda</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>Transakcio estas tro granda</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>Salutnomo por konektoj JSON-RPC</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Averto</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Pasvorto por konektoj JSON-RPC</translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation>Plenumi komandon kiam plej bona bloko ŝanĝiĝas (%s en cmd anstataŭiĝas per bloka haketaĵo)</translation>
    </message>
    <message>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>Permesi DNS-elserĉojn por -addnote, -seednote kaj -connect</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>Ŝarĝante adresojn...</translation>
    </message>
    <message>
        <source>Invalid -proxy address: '%s'</source>
        <translation>Nevalid adreso -proxy: '%s'</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: '%s'</source>
        <translation>Nekonata reto specifita en -onlynet: '%s'</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>Nesufiĉa mono</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Ŝarĝante blok-indekson...</translation>
    </message>
    <message>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>Aldoni nodon por alkonekti kaj provi daŭrigi la malferman konekton</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Ŝargado de monujo...</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>Ne eblas malpromocii monujon</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>Ne eblas skribi defaŭltan adreson</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Reskanado...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Ŝargado finiĝis</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Eraro</translation>
    </message>
</context>
</TS>