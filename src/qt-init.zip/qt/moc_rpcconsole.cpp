/****************************************************************************
** Meta object code from reading C++ file 'rpcconsole.h'
**
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "qt/rpcconsole.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'rpcconsole.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_RPCConsole_t {
    QByteArrayData data[63];
    char stringdata0[851];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_RPCConsole_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_RPCConsole_t qt_meta_stringdata_RPCConsole = {
    {
QT_MOC_LITERAL(0, 0, 10), // "RPCConsole"
QT_MOC_LITERAL(1, 11, 12), // "stopExecutor"
QT_MOC_LITERAL(2, 24, 0), // ""
QT_MOC_LITERAL(3, 25, 10), // "cmdRequest"
QT_MOC_LITERAL(4, 36, 7), // "command"
QT_MOC_LITERAL(5, 44, 25), // "on_lineEdit_returnPressed"
QT_MOC_LITERAL(6, 70, 27), // "on_tabWidget_currentChanged"
QT_MOC_LITERAL(7, 98, 5), // "index"
QT_MOC_LITERAL(8, 104, 33), // "on_openDebugLogfileButton_cli..."
QT_MOC_LITERAL(9, 138, 29), // "on_sldGraphRange_valueChanged"
QT_MOC_LITERAL(10, 168, 5), // "value"
QT_MOC_LITERAL(11, 174, 18), // "updateTrafficStats"
QT_MOC_LITERAL(12, 193, 12), // "totalBytesIn"
QT_MOC_LITERAL(13, 206, 13), // "totalBytesOut"
QT_MOC_LITERAL(14, 220, 11), // "resizeEvent"
QT_MOC_LITERAL(15, 232, 13), // "QResizeEvent*"
QT_MOC_LITERAL(16, 246, 5), // "event"
QT_MOC_LITERAL(17, 252, 9), // "showEvent"
QT_MOC_LITERAL(18, 262, 11), // "QShowEvent*"
QT_MOC_LITERAL(19, 274, 9), // "hideEvent"
QT_MOC_LITERAL(20, 284, 11), // "QHideEvent*"
QT_MOC_LITERAL(21, 296, 25), // "showPeersTableContextMenu"
QT_MOC_LITERAL(22, 322, 5), // "point"
QT_MOC_LITERAL(23, 328, 23), // "showBanTableContextMenu"
QT_MOC_LITERAL(24, 352, 28), // "showOrHideBanTableIfRequired"
QT_MOC_LITERAL(25, 381, 17), // "clearSelectedNode"
QT_MOC_LITERAL(26, 399, 5), // "clear"
QT_MOC_LITERAL(27, 405, 12), // "clearHistory"
QT_MOC_LITERAL(28, 418, 10), // "fontBigger"
QT_MOC_LITERAL(29, 429, 11), // "fontSmaller"
QT_MOC_LITERAL(30, 441, 11), // "setFontSize"
QT_MOC_LITERAL(31, 453, 7), // "newSize"
QT_MOC_LITERAL(32, 461, 7), // "message"
QT_MOC_LITERAL(33, 469, 8), // "category"
QT_MOC_LITERAL(34, 478, 4), // "html"
QT_MOC_LITERAL(35, 483, 17), // "setNumConnections"
QT_MOC_LITERAL(36, 501, 5), // "count"
QT_MOC_LITERAL(37, 507, 16), // "setNetworkActive"
QT_MOC_LITERAL(38, 524, 13), // "networkActive"
QT_MOC_LITERAL(39, 538, 12), // "setNumBlocks"
QT_MOC_LITERAL(40, 551, 9), // "blockDate"
QT_MOC_LITERAL(41, 561, 21), // "nVerificationProgress"
QT_MOC_LITERAL(42, 583, 7), // "headers"
QT_MOC_LITERAL(43, 591, 14), // "setMempoolSize"
QT_MOC_LITERAL(44, 606, 11), // "numberOfTxs"
QT_MOC_LITERAL(45, 618, 6), // "size_t"
QT_MOC_LITERAL(46, 625, 8), // "dynUsage"
QT_MOC_LITERAL(47, 634, 13), // "browseHistory"
QT_MOC_LITERAL(48, 648, 6), // "offset"
QT_MOC_LITERAL(49, 655, 11), // "scrollToEnd"
QT_MOC_LITERAL(50, 667, 12), // "peerSelected"
QT_MOC_LITERAL(51, 680, 14), // "QItemSelection"
QT_MOC_LITERAL(52, 695, 8), // "selected"
QT_MOC_LITERAL(53, 704, 10), // "deselected"
QT_MOC_LITERAL(54, 715, 23), // "peerLayoutAboutToChange"
QT_MOC_LITERAL(55, 739, 17), // "peerLayoutChanged"
QT_MOC_LITERAL(56, 757, 22), // "disconnectSelectedNode"
QT_MOC_LITERAL(57, 780, 15), // "banSelectedNode"
QT_MOC_LITERAL(58, 796, 7), // "bantime"
QT_MOC_LITERAL(59, 804, 17), // "unbanSelectedNode"
QT_MOC_LITERAL(60, 822, 11), // "setTabFocus"
QT_MOC_LITERAL(61, 834, 8), // "TabTypes"
QT_MOC_LITERAL(62, 843, 7) // "tabType"

    },
    "RPCConsole\0stopExecutor\0\0cmdRequest\0"
    "command\0on_lineEdit_returnPressed\0"
    "on_tabWidget_currentChanged\0index\0"
    "on_openDebugLogfileButton_clicked\0"
    "on_sldGraphRange_valueChanged\0value\0"
    "updateTrafficStats\0totalBytesIn\0"
    "totalBytesOut\0resizeEvent\0QResizeEvent*\0"
    "event\0showEvent\0QShowEvent*\0hideEvent\0"
    "QHideEvent*\0showPeersTableContextMenu\0"
    "point\0showBanTableContextMenu\0"
    "showOrHideBanTableIfRequired\0"
    "clearSelectedNode\0clear\0clearHistory\0"
    "fontBigger\0fontSmaller\0setFontSize\0"
    "newSize\0message\0category\0html\0"
    "setNumConnections\0count\0setNetworkActive\0"
    "networkActive\0setNumBlocks\0blockDate\0"
    "nVerificationProgress\0headers\0"
    "setMempoolSize\0numberOfTxs\0size_t\0"
    "dynUsage\0browseHistory\0offset\0scrollToEnd\0"
    "peerSelected\0QItemSelection\0selected\0"
    "deselected\0peerLayoutAboutToChange\0"
    "peerLayoutChanged\0disconnectSelectedNode\0"
    "banSelectedNode\0bantime\0unbanSelectedNode\0"
    "setTabFocus\0TabTypes\0tabType"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_RPCConsole[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      34,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  184,    2, 0x06 /* Public */,
       3,    1,  185,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    0,  188,    2, 0x08 /* Private */,
       6,    1,  189,    2, 0x08 /* Private */,
       8,    0,  192,    2, 0x08 /* Private */,
       9,    1,  193,    2, 0x08 /* Private */,
      11,    2,  196,    2, 0x08 /* Private */,
      14,    1,  201,    2, 0x08 /* Private */,
      17,    1,  204,    2, 0x08 /* Private */,
      19,    1,  207,    2, 0x08 /* Private */,
      21,    1,  210,    2, 0x08 /* Private */,
      23,    1,  213,    2, 0x08 /* Private */,
      24,    0,  216,    2, 0x08 /* Private */,
      25,    0,  217,    2, 0x08 /* Private */,
      26,    1,  218,    2, 0x0a /* Public */,
      26,    0,  221,    2, 0x2a /* Public | MethodCloned */,
      28,    0,  222,    2, 0x0a /* Public */,
      29,    0,  223,    2, 0x0a /* Public */,
      30,    1,  224,    2, 0x0a /* Public */,
      32,    3,  227,    2, 0x0a /* Public */,
      32,    2,  234,    2, 0x2a /* Public | MethodCloned */,
      35,    1,  239,    2, 0x0a /* Public */,
      37,    1,  242,    2, 0x0a /* Public */,
      39,    4,  245,    2, 0x0a /* Public */,
      43,    2,  254,    2, 0x0a /* Public */,
      47,    1,  259,    2, 0x0a /* Public */,
      49,    0,  262,    2, 0x0a /* Public */,
      50,    2,  263,    2, 0x0a /* Public */,
      54,    0,  268,    2, 0x0a /* Public */,
      55,    0,  269,    2, 0x0a /* Public */,
      56,    0,  270,    2, 0x0a /* Public */,
      57,    1,  271,    2, 0x0a /* Public */,
      59,    0,  274,    2, 0x0a /* Public */,
      60,    1,  275,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    4,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   10,
    QMetaType::Void, QMetaType::ULongLong, QMetaType::ULongLong,   12,   13,
    QMetaType::Void, 0x80000000 | 15,   16,
    QMetaType::Void, 0x80000000 | 18,   16,
    QMetaType::Void, 0x80000000 | 20,   16,
    QMetaType::Void, QMetaType::QPoint,   22,
    QMetaType::Void, QMetaType::QPoint,   22,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   27,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   31,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::Bool,   33,   32,   34,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   33,   32,
    QMetaType::Void, QMetaType::Int,   36,
    QMetaType::Void, QMetaType::Bool,   38,
    QMetaType::Void, QMetaType::Int, QMetaType::QDateTime, QMetaType::Double, QMetaType::Bool,   36,   40,   41,   42,
    QMetaType::Void, QMetaType::Long, 0x80000000 | 45,   44,   46,
    QMetaType::Void, QMetaType::Int,   48,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 51, 0x80000000 | 51,   52,   53,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   58,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 61,   62,

       0        // eod
};

void RPCConsole::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        RPCConsole *_t = static_cast<RPCConsole *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->stopExecutor(); break;
        case 1: _t->cmdRequest((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: _t->on_lineEdit_returnPressed(); break;
        case 3: _t->on_tabWidget_currentChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->on_openDebugLogfileButton_clicked(); break;
        case 5: _t->on_sldGraphRange_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->updateTrafficStats((*reinterpret_cast< quint64(*)>(_a[1])),(*reinterpret_cast< quint64(*)>(_a[2]))); break;
        case 7: _t->resizeEvent((*reinterpret_cast< QResizeEvent*(*)>(_a[1]))); break;
        case 8: _t->showEvent((*reinterpret_cast< QShowEvent*(*)>(_a[1]))); break;
        case 9: _t->hideEvent((*reinterpret_cast< QHideEvent*(*)>(_a[1]))); break;
        case 10: _t->showPeersTableContextMenu((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 11: _t->showBanTableContextMenu((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 12: _t->showOrHideBanTableIfRequired(); break;
        case 13: _t->clearSelectedNode(); break;
        case 14: _t->clear((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 15: _t->clear(); break;
        case 16: _t->fontBigger(); break;
        case 17: _t->fontSmaller(); break;
        case 18: _t->setFontSize((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: _t->message((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3]))); break;
        case 20: _t->message((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 21: _t->setNumConnections((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 22: _t->setNetworkActive((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 23: _t->setNumBlocks((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< const QDateTime(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4]))); break;
        case 24: _t->setMempoolSize((*reinterpret_cast< long(*)>(_a[1])),(*reinterpret_cast< size_t(*)>(_a[2]))); break;
        case 25: _t->browseHistory((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 26: _t->scrollToEnd(); break;
        case 27: _t->peerSelected((*reinterpret_cast< const QItemSelection(*)>(_a[1])),(*reinterpret_cast< const QItemSelection(*)>(_a[2]))); break;
        case 28: _t->peerLayoutAboutToChange(); break;
        case 29: _t->peerLayoutChanged(); break;
        case 30: _t->disconnectSelectedNode(); break;
        case 31: _t->banSelectedNode((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 32: _t->unbanSelectedNode(); break;
        case 33: _t->setTabFocus((*reinterpret_cast< TabTypes(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 27:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QItemSelection >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (RPCConsole::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&RPCConsole::stopExecutor)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (RPCConsole::*_t)(const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&RPCConsole::cmdRequest)) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject RPCConsole::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_RPCConsole.data,
      qt_meta_data_RPCConsole,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *RPCConsole::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *RPCConsole::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_RPCConsole.stringdata0))
        return static_cast<void*>(const_cast< RPCConsole*>(this));
    return QWidget::qt_metacast(_clname);
}

int RPCConsole::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 34)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 34;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 34)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 34;
    }
    return _id;
}

// SIGNAL 0
void RPCConsole::stopExecutor()
{
    QMetaObject::activate(this, &staticMetaObject, 0, Q_NULLPTR);
}

// SIGNAL 1
void RPCConsole::cmdRequest(const QString & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_END_MOC_NAMESPACE
