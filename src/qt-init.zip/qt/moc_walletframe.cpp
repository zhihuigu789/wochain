/****************************************************************************
** Meta object code from reading C++ file 'walletframe.h'
**
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "qt/walletframe.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'walletframe.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_WalletFrame_t {
    QByteArrayData data[28];
    char stringdata0[453];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_WalletFrame_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_WalletFrame_t qt_meta_stringdata_WalletFrame = {
    {
QT_MOC_LITERAL(0, 0, 11), // "WalletFrame"
QT_MOC_LITERAL(1, 12, 24), // "requestedSyncWarningInfo"
QT_MOC_LITERAL(2, 37, 0), // ""
QT_MOC_LITERAL(3, 38, 16), // "gotoOverviewPage"
QT_MOC_LITERAL(4, 55, 15), // "gotoHistoryPage"
QT_MOC_LITERAL(5, 71, 20), // "gotoReceiveCoinsPage"
QT_MOC_LITERAL(6, 92, 17), // "gotoSendCoinsPage"
QT_MOC_LITERAL(7, 110, 4), // "addr"
QT_MOC_LITERAL(8, 115, 22), // "gotoCreateContractPage"
QT_MOC_LITERAL(9, 138, 22), // "gotoSendToContractPage"
QT_MOC_LITERAL(10, 161, 20), // "gotoCallContractPage"
QT_MOC_LITERAL(11, 182, 17), // "gotoSendTokenPage"
QT_MOC_LITERAL(12, 200, 20), // "gotoReceiveTokenPage"
QT_MOC_LITERAL(13, 221, 16), // "gotoAddTokenPage"
QT_MOC_LITERAL(14, 238, 18), // "gotoSignMessageTab"
QT_MOC_LITERAL(15, 257, 20), // "gotoVerifyMessageTab"
QT_MOC_LITERAL(16, 278, 13), // "encryptWallet"
QT_MOC_LITERAL(17, 292, 6), // "status"
QT_MOC_LITERAL(18, 299, 12), // "backupWallet"
QT_MOC_LITERAL(19, 312, 13), // "restoreWallet"
QT_MOC_LITERAL(20, 326, 16), // "changePassphrase"
QT_MOC_LITERAL(21, 343, 12), // "unlockWallet"
QT_MOC_LITERAL(22, 356, 10), // "lockWallet"
QT_MOC_LITERAL(23, 367, 20), // "usedSendingAddresses"
QT_MOC_LITERAL(24, 388, 22), // "usedReceivingAddresses"
QT_MOC_LITERAL(25, 411, 23), // "outOfSyncWarningClicked"
QT_MOC_LITERAL(26, 435, 11), // "pageChanged"
QT_MOC_LITERAL(27, 447, 5) // "index"

    },
    "WalletFrame\0requestedSyncWarningInfo\0"
    "\0gotoOverviewPage\0gotoHistoryPage\0"
    "gotoReceiveCoinsPage\0gotoSendCoinsPage\0"
    "addr\0gotoCreateContractPage\0"
    "gotoSendToContractPage\0gotoCallContractPage\0"
    "gotoSendTokenPage\0gotoReceiveTokenPage\0"
    "gotoAddTokenPage\0gotoSignMessageTab\0"
    "gotoVerifyMessageTab\0encryptWallet\0"
    "status\0backupWallet\0restoreWallet\0"
    "changePassphrase\0unlockWallet\0lockWallet\0"
    "usedSendingAddresses\0usedReceivingAddresses\0"
    "outOfSyncWarningClicked\0pageChanged\0"
    "index"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_WalletFrame[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      26,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  144,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    0,  145,    2, 0x0a /* Public */,
       4,    0,  146,    2, 0x0a /* Public */,
       5,    0,  147,    2, 0x0a /* Public */,
       6,    1,  148,    2, 0x0a /* Public */,
       6,    0,  151,    2, 0x2a /* Public | MethodCloned */,
       8,    0,  152,    2, 0x0a /* Public */,
       9,    0,  153,    2, 0x0a /* Public */,
      10,    0,  154,    2, 0x0a /* Public */,
      11,    0,  155,    2, 0x0a /* Public */,
      12,    0,  156,    2, 0x0a /* Public */,
      13,    0,  157,    2, 0x0a /* Public */,
      14,    1,  158,    2, 0x0a /* Public */,
      14,    0,  161,    2, 0x2a /* Public | MethodCloned */,
      15,    1,  162,    2, 0x0a /* Public */,
      15,    0,  165,    2, 0x2a /* Public | MethodCloned */,
      16,    1,  166,    2, 0x0a /* Public */,
      18,    0,  169,    2, 0x0a /* Public */,
      19,    0,  170,    2, 0x0a /* Public */,
      20,    0,  171,    2, 0x0a /* Public */,
      21,    0,  172,    2, 0x0a /* Public */,
      22,    0,  173,    2, 0x0a /* Public */,
      23,    0,  174,    2, 0x0a /* Public */,
      24,    0,  175,    2, 0x0a /* Public */,
      25,    0,  176,    2, 0x0a /* Public */,
      26,    1,  177,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   17,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   27,

       0        // eod
};

void WalletFrame::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        WalletFrame *_t = static_cast<WalletFrame *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->requestedSyncWarningInfo(); break;
        case 1: _t->gotoOverviewPage(); break;
        case 2: _t->gotoHistoryPage(); break;
        case 3: _t->gotoReceiveCoinsPage(); break;
        case 4: _t->gotoSendCoinsPage((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: _t->gotoSendCoinsPage(); break;
        case 6: _t->gotoCreateContractPage(); break;
        case 7: _t->gotoSendToContractPage(); break;
        case 8: _t->gotoCallContractPage(); break;
        case 9: _t->gotoSendTokenPage(); break;
        case 10: _t->gotoReceiveTokenPage(); break;
        case 11: _t->gotoAddTokenPage(); break;
        case 12: _t->gotoSignMessageTab((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 13: _t->gotoSignMessageTab(); break;
        case 14: _t->gotoVerifyMessageTab((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 15: _t->gotoVerifyMessageTab(); break;
        case 16: _t->encryptWallet((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 17: _t->backupWallet(); break;
        case 18: _t->restoreWallet(); break;
        case 19: _t->changePassphrase(); break;
        case 20: _t->unlockWallet(); break;
        case 21: _t->lockWallet(); break;
        case 22: _t->usedSendingAddresses(); break;
        case 23: _t->usedReceivingAddresses(); break;
        case 24: _t->outOfSyncWarningClicked(); break;
        case 25: _t->pageChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (WalletFrame::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&WalletFrame::requestedSyncWarningInfo)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject WalletFrame::staticMetaObject = {
    { &QFrame::staticMetaObject, qt_meta_stringdata_WalletFrame.data,
      qt_meta_data_WalletFrame,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *WalletFrame::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *WalletFrame::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_WalletFrame.stringdata0))
        return static_cast<void*>(const_cast< WalletFrame*>(this));
    return QFrame::qt_metacast(_clname);
}

int WalletFrame::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 26)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 26;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 26)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 26;
    }
    return _id;
}

// SIGNAL 0
void WalletFrame::requestedSyncWarningInfo()
{
    QMetaObject::activate(this, &staticMetaObject, 0, Q_NULLPTR);
}
QT_END_MOC_NAMESPACE
