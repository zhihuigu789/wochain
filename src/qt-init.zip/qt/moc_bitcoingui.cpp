/****************************************************************************
** Meta object code from reading C++ file 'bitcoingui.h'
**
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "qt/bitcoingui.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'bitcoingui.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_BitcoinGUI_t {
    QByteArrayData data[69];
    char stringdata0[979];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_BitcoinGUI_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_BitcoinGUI_t qt_meta_stringdata_BitcoinGUI = {
    {
QT_MOC_LITERAL(0, 0, 10), // "BitcoinGUI"
QT_MOC_LITERAL(1, 11, 11), // "receivedURI"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 3), // "uri"
QT_MOC_LITERAL(4, 28, 17), // "setNumConnections"
QT_MOC_LITERAL(5, 46, 5), // "count"
QT_MOC_LITERAL(6, 52, 16), // "setNetworkActive"
QT_MOC_LITERAL(7, 69, 13), // "networkActive"
QT_MOC_LITERAL(8, 83, 12), // "setNumBlocks"
QT_MOC_LITERAL(9, 96, 9), // "blockDate"
QT_MOC_LITERAL(10, 106, 21), // "nVerificationProgress"
QT_MOC_LITERAL(11, 128, 7), // "headers"
QT_MOC_LITERAL(12, 136, 7), // "message"
QT_MOC_LITERAL(13, 144, 5), // "title"
QT_MOC_LITERAL(14, 150, 5), // "style"
QT_MOC_LITERAL(15, 156, 5), // "bool*"
QT_MOC_LITERAL(16, 162, 3), // "ret"
QT_MOC_LITERAL(17, 166, 19), // "setEncryptionStatus"
QT_MOC_LITERAL(18, 186, 6), // "status"
QT_MOC_LITERAL(19, 193, 11), // "setHDStatus"
QT_MOC_LITERAL(20, 205, 9), // "hdEnabled"
QT_MOC_LITERAL(21, 215, 20), // "handlePaymentRequest"
QT_MOC_LITERAL(22, 236, 18), // "SendCoinsRecipient"
QT_MOC_LITERAL(23, 255, 9), // "recipient"
QT_MOC_LITERAL(24, 265, 19), // "incomingTransaction"
QT_MOC_LITERAL(25, 285, 4), // "date"
QT_MOC_LITERAL(26, 290, 4), // "unit"
QT_MOC_LITERAL(27, 295, 7), // "CAmount"
QT_MOC_LITERAL(28, 303, 6), // "amount"
QT_MOC_LITERAL(29, 310, 4), // "type"
QT_MOC_LITERAL(30, 315, 7), // "address"
QT_MOC_LITERAL(31, 323, 5), // "label"
QT_MOC_LITERAL(32, 329, 24), // "incomingTokenTransaction"
QT_MOC_LITERAL(33, 354, 13), // "setTabBarInfo"
QT_MOC_LITERAL(34, 368, 4), // "into"
QT_MOC_LITERAL(35, 373, 16), // "gotoOverviewPage"
QT_MOC_LITERAL(36, 390, 15), // "gotoHistoryPage"
QT_MOC_LITERAL(37, 406, 20), // "gotoReceiveCoinsPage"
QT_MOC_LITERAL(38, 427, 17), // "gotoSendCoinsPage"
QT_MOC_LITERAL(39, 445, 4), // "addr"
QT_MOC_LITERAL(40, 450, 22), // "gotoCreateContractPage"
QT_MOC_LITERAL(41, 473, 22), // "gotoSendToContractPage"
QT_MOC_LITERAL(42, 496, 20), // "gotoCallContractPage"
QT_MOC_LITERAL(43, 517, 17), // "gotoSendTokenPage"
QT_MOC_LITERAL(44, 535, 20), // "gotoReceiveTokenPage"
QT_MOC_LITERAL(45, 556, 16), // "gotoAddTokenPage"
QT_MOC_LITERAL(46, 573, 18), // "gotoSignMessageTab"
QT_MOC_LITERAL(47, 592, 20), // "gotoVerifyMessageTab"
QT_MOC_LITERAL(48, 613, 11), // "openClicked"
QT_MOC_LITERAL(49, 625, 14), // "optionsClicked"
QT_MOC_LITERAL(50, 640, 12), // "aboutClicked"
QT_MOC_LITERAL(51, 653, 15), // "showDebugWindow"
QT_MOC_LITERAL(52, 669, 30), // "showDebugWindowActivateConsole"
QT_MOC_LITERAL(53, 700, 22), // "showHelpMessageClicked"
QT_MOC_LITERAL(54, 723, 17), // "trayIconActivated"
QT_MOC_LITERAL(55, 741, 33), // "QSystemTrayIcon::ActivationRe..."
QT_MOC_LITERAL(56, 775, 6), // "reason"
QT_MOC_LITERAL(57, 782, 21), // "showNormalIfMinimized"
QT_MOC_LITERAL(58, 804, 13), // "fToggleHidden"
QT_MOC_LITERAL(59, 818, 12), // "toggleHidden"
QT_MOC_LITERAL(60, 831, 12), // "updateWeight"
QT_MOC_LITERAL(61, 844, 17), // "updateStakingIcon"
QT_MOC_LITERAL(62, 862, 14), // "detectShutdown"
QT_MOC_LITERAL(63, 877, 12), // "showProgress"
QT_MOC_LITERAL(64, 890, 9), // "nProgress"
QT_MOC_LITERAL(65, 900, 18), // "setTrayIconVisible"
QT_MOC_LITERAL(66, 919, 19), // "toggleNetworkActive"
QT_MOC_LITERAL(67, 939, 16), // "showModalOverlay"
QT_MOC_LITERAL(68, 956, 22) // "showModalBackupOverlay"

    },
    "BitcoinGUI\0receivedURI\0\0uri\0"
    "setNumConnections\0count\0setNetworkActive\0"
    "networkActive\0setNumBlocks\0blockDate\0"
    "nVerificationProgress\0headers\0message\0"
    "title\0style\0bool*\0ret\0setEncryptionStatus\0"
    "status\0setHDStatus\0hdEnabled\0"
    "handlePaymentRequest\0SendCoinsRecipient\0"
    "recipient\0incomingTransaction\0date\0"
    "unit\0CAmount\0amount\0type\0address\0label\0"
    "incomingTokenTransaction\0setTabBarInfo\0"
    "into\0gotoOverviewPage\0gotoHistoryPage\0"
    "gotoReceiveCoinsPage\0gotoSendCoinsPage\0"
    "addr\0gotoCreateContractPage\0"
    "gotoSendToContractPage\0gotoCallContractPage\0"
    "gotoSendTokenPage\0gotoReceiveTokenPage\0"
    "gotoAddTokenPage\0gotoSignMessageTab\0"
    "gotoVerifyMessageTab\0openClicked\0"
    "optionsClicked\0aboutClicked\0showDebugWindow\0"
    "showDebugWindowActivateConsole\0"
    "showHelpMessageClicked\0trayIconActivated\0"
    "QSystemTrayIcon::ActivationReason\0"
    "reason\0showNormalIfMinimized\0fToggleHidden\0"
    "toggleHidden\0updateWeight\0updateStakingIcon\0"
    "detectShutdown\0showProgress\0nProgress\0"
    "setTrayIconVisible\0toggleNetworkActive\0"
    "showModalOverlay\0showModalBackupOverlay"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_BitcoinGUI[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      45,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  239,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    1,  242,    2, 0x0a /* Public */,
       6,    1,  245,    2, 0x0a /* Public */,
       8,    4,  248,    2, 0x0a /* Public */,
      12,    4,  257,    2, 0x0a /* Public */,
      12,    3,  266,    2, 0x2a /* Public | MethodCloned */,
      17,    1,  273,    2, 0x0a /* Public */,
      19,    1,  276,    2, 0x0a /* Public */,
      21,    1,  279,    2, 0x0a /* Public */,
      24,    6,  282,    2, 0x0a /* Public */,
      32,    6,  295,    2, 0x0a /* Public */,
      33,    1,  308,    2, 0x0a /* Public */,
      35,    0,  311,    2, 0x08 /* Private */,
      36,    0,  312,    2, 0x08 /* Private */,
      37,    0,  313,    2, 0x08 /* Private */,
      38,    1,  314,    2, 0x08 /* Private */,
      38,    0,  317,    2, 0x28 /* Private | MethodCloned */,
      40,    0,  318,    2, 0x08 /* Private */,
      41,    0,  319,    2, 0x08 /* Private */,
      42,    0,  320,    2, 0x08 /* Private */,
      43,    0,  321,    2, 0x08 /* Private */,
      44,    0,  322,    2, 0x08 /* Private */,
      45,    0,  323,    2, 0x08 /* Private */,
      46,    1,  324,    2, 0x08 /* Private */,
      46,    0,  327,    2, 0x28 /* Private | MethodCloned */,
      47,    1,  328,    2, 0x08 /* Private */,
      47,    0,  331,    2, 0x28 /* Private | MethodCloned */,
      48,    0,  332,    2, 0x08 /* Private */,
      49,    0,  333,    2, 0x08 /* Private */,
      50,    0,  334,    2, 0x08 /* Private */,
      51,    0,  335,    2, 0x08 /* Private */,
      52,    0,  336,    2, 0x08 /* Private */,
      53,    0,  337,    2, 0x08 /* Private */,
      54,    1,  338,    2, 0x08 /* Private */,
      57,    1,  341,    2, 0x08 /* Private */,
      57,    0,  344,    2, 0x28 /* Private | MethodCloned */,
      59,    0,  345,    2, 0x08 /* Private */,
      60,    0,  346,    2, 0x08 /* Private */,
      61,    0,  347,    2, 0x08 /* Private */,
      62,    0,  348,    2, 0x08 /* Private */,
      63,    2,  349,    2, 0x08 /* Private */,
      65,    1,  354,    2, 0x08 /* Private */,
      66,    0,  357,    2, 0x08 /* Private */,
      67,    0,  358,    2, 0x08 /* Private */,
      68,    0,  359,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Bool,    7,
    QMetaType::Void, QMetaType::Int, QMetaType::QDateTime, QMetaType::Double, QMetaType::Bool,    5,    9,   10,   11,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::UInt, 0x80000000 | 15,   13,   12,   14,   16,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::UInt,   13,   12,   14,
    QMetaType::Void, QMetaType::Int,   18,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Bool, 0x80000000 | 22,   23,
    QMetaType::Void, QMetaType::QString, QMetaType::Int, 0x80000000 | 27, QMetaType::QString, QMetaType::QString, QMetaType::QString,   25,   26,   28,   29,   30,   31,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,   25,   28,   29,   30,   31,   13,
    QMetaType::Void, QMetaType::QObjectStar,   34,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   39,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   39,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   39,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 55,   56,
    QMetaType::Void, QMetaType::Bool,   58,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   13,   64,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void BitcoinGUI::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        BitcoinGUI *_t = static_cast<BitcoinGUI *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->receivedURI((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 1: _t->setNumConnections((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->setNetworkActive((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->setNumBlocks((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< const QDateTime(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4]))); break;
        case 4: _t->message((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< uint(*)>(_a[3])),(*reinterpret_cast< bool*(*)>(_a[4]))); break;
        case 5: _t->message((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< uint(*)>(_a[3]))); break;
        case 6: _t->setEncryptionStatus((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->setHDStatus((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: { bool _r = _t->handlePaymentRequest((*reinterpret_cast< const SendCoinsRecipient(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 9: _t->incomingTransaction((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< const CAmount(*)>(_a[3])),(*reinterpret_cast< const QString(*)>(_a[4])),(*reinterpret_cast< const QString(*)>(_a[5])),(*reinterpret_cast< const QString(*)>(_a[6]))); break;
        case 10: _t->incomingTokenTransaction((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< const QString(*)>(_a[3])),(*reinterpret_cast< const QString(*)>(_a[4])),(*reinterpret_cast< const QString(*)>(_a[5])),(*reinterpret_cast< const QString(*)>(_a[6]))); break;
        case 11: _t->setTabBarInfo((*reinterpret_cast< QObject*(*)>(_a[1]))); break;
        case 12: _t->gotoOverviewPage(); break;
        case 13: _t->gotoHistoryPage(); break;
        case 14: _t->gotoReceiveCoinsPage(); break;
        case 15: _t->gotoSendCoinsPage((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 16: _t->gotoSendCoinsPage(); break;
        case 17: _t->gotoCreateContractPage(); break;
        case 18: _t->gotoSendToContractPage(); break;
        case 19: _t->gotoCallContractPage(); break;
        case 20: _t->gotoSendTokenPage(); break;
        case 21: _t->gotoReceiveTokenPage(); break;
        case 22: _t->gotoAddTokenPage(); break;
        case 23: _t->gotoSignMessageTab((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 24: _t->gotoSignMessageTab(); break;
        case 25: _t->gotoVerifyMessageTab((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 26: _t->gotoVerifyMessageTab(); break;
        case 27: _t->openClicked(); break;
        case 28: _t->optionsClicked(); break;
        case 29: _t->aboutClicked(); break;
        case 30: _t->showDebugWindow(); break;
        case 31: _t->showDebugWindowActivateConsole(); break;
        case 32: _t->showHelpMessageClicked(); break;
        case 33: _t->trayIconActivated((*reinterpret_cast< QSystemTrayIcon::ActivationReason(*)>(_a[1]))); break;
        case 34: _t->showNormalIfMinimized((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 35: _t->showNormalIfMinimized(); break;
        case 36: _t->toggleHidden(); break;
        case 37: _t->updateWeight(); break;
        case 38: _t->updateStakingIcon(); break;
        case 39: _t->detectShutdown(); break;
        case 40: _t->showProgress((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 41: _t->setTrayIconVisible((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 42: _t->toggleNetworkActive(); break;
        case 43: _t->showModalOverlay(); break;
        case 44: _t->showModalBackupOverlay(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (BitcoinGUI::*_t)(const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&BitcoinGUI::receivedURI)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject BitcoinGUI::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_BitcoinGUI.data,
      qt_meta_data_BitcoinGUI,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *BitcoinGUI::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *BitcoinGUI::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_BitcoinGUI.stringdata0))
        return static_cast<void*>(const_cast< BitcoinGUI*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int BitcoinGUI::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 45)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 45;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 45)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 45;
    }
    return _id;
}

// SIGNAL 0
void BitcoinGUI::receivedURI(const QString & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
struct qt_meta_stringdata_UnitDisplayStatusBarControl_t {
    QByteArrayData data[7];
    char stringdata0[88];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_UnitDisplayStatusBarControl_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_UnitDisplayStatusBarControl_t qt_meta_stringdata_UnitDisplayStatusBarControl = {
    {
QT_MOC_LITERAL(0, 0, 27), // "UnitDisplayStatusBarControl"
QT_MOC_LITERAL(1, 28, 17), // "updateDisplayUnit"
QT_MOC_LITERAL(2, 46, 0), // ""
QT_MOC_LITERAL(3, 47, 8), // "newUnits"
QT_MOC_LITERAL(4, 56, 15), // "onMenuSelection"
QT_MOC_LITERAL(5, 72, 8), // "QAction*"
QT_MOC_LITERAL(6, 81, 6) // "action"

    },
    "UnitDisplayStatusBarControl\0"
    "updateDisplayUnit\0\0newUnits\0onMenuSelection\0"
    "QAction*\0action"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_UnitDisplayStatusBarControl[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   24,    2, 0x08 /* Private */,
       4,    1,   27,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, 0x80000000 | 5,    6,

       0        // eod
};

void UnitDisplayStatusBarControl::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        UnitDisplayStatusBarControl *_t = static_cast<UnitDisplayStatusBarControl *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateDisplayUnit((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->onMenuSelection((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QAction* >(); break;
            }
            break;
        }
    }
}

const QMetaObject UnitDisplayStatusBarControl::staticMetaObject = {
    { &QLabel::staticMetaObject, qt_meta_stringdata_UnitDisplayStatusBarControl.data,
      qt_meta_data_UnitDisplayStatusBarControl,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *UnitDisplayStatusBarControl::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *UnitDisplayStatusBarControl::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_UnitDisplayStatusBarControl.stringdata0))
        return static_cast<void*>(const_cast< UnitDisplayStatusBarControl*>(this));
    return QLabel::qt_metacast(_clname);
}

int UnitDisplayStatusBarControl::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QLabel::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
