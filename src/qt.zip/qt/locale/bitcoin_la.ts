<TS language="la" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Create a new address</source>
        <translation>Crea novam inscriptionem</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Copia inscriptionem iam selectam in latibulum systematis</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Dele active selectam inscriptionem ex enumeratione</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Exporta data in hac tabella in plicam</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Exporta</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Dele</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Dialogus Tesserae</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Insere tesseram</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Nova tessera</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Itera novam tesseram</translation>
    </message>
    </context>
<context>
    <name>BanTableModel</name>
    </context>
<context>
    <name>IotxGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>Signa &amp;nuntium...</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Synchronizans cum rete...</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Summarium</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Monstra generale summarium cassidilis</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Transactiones</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Inspicio historiam transactionum</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>E&amp;xi</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Exi applicatione</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Informatio de &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Monstra informationem de Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Optiones</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>&amp;Cifra Cassidile...</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;Conserva Cassidile...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;Muta tesseram...</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>Recreans indicem frustorum in disco...</translation>
    </message>
    <message>
        <source>Send coins to a Iotx address</source>
        <translation>Mitte nummos ad inscriptionem Iotx</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Conserva cassidile in locum alium</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Muta tesseram utam pro cassidilis cifrando</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>Fenestra &amp;Debug</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>Aperi terminalem debug et diagnosticalem</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>&amp;Verifica nuntium...</translation>
    </message>
    <message>
        <source>Iotx</source>
        <translation>Iotx</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Cassidile</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Mitte</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation>&amp;Accipe</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Monstra/Occulta</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>Monstra vel occulta Fenestram principem</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>Cifra claves privatas quae cassidili tui sunt</translation>
    </message>
    <message>
        <source>Sign messages with your Iotx addresses to prove you own them</source>
        <translation>Signa nuntios cum tuis inscriptionibus Iotx ut demonstres te eas possidere</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Iotx addresses</source>
        <translation>Verifica nuntios ut certus sis eos signatos esse cum specificatis inscriptionibus Iotx</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Plica</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Configuratio</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Auxilium</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Tabella instrumentorum "Tabs"</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>Optiones mandati initiantis</translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>%1 post</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>Postremum acceptum frustum generatum est %1 abhinc.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>Transactiones post hoc nondum visibiles erunt.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Monitio</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Informatio</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Recentissimo</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Persequens...</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Transactio missa</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Transactio incipiens</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Cassidile &lt;b&gt;cifratum&lt;/b&gt; est et iam nunc &lt;b&gt;reseratum&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Cassidile &lt;b&gt;cifratum&lt;/b&gt; est et iam nunc &lt;b&gt;seratum&lt;/b&gt;</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Amount:</source>
        <translation>Quantitas:</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Quantitas</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Dies</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Confirmatum</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Muta Inscriptionem</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Titulus</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Inscriptio</translation>
    </message>
    </context>
<context>
    <name>FreespaceChecker</name>
    </context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation>versio</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>Optiones mandati initiantis</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>Usus:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>Optiones mandati intiantis</translation>
    </message>
    </context>
<context>
    <name>Intro</name>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    </context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation>Schema</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Hora postremi frusti</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Optiones</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>&amp;Princeps</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation>Reconstitue omnes optiones clientis ad praedefinita.</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation>&amp;Reconstitue Optiones</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;Rete</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>Cassidile</translation>
    </message>
    <message>
        <source>Automatically open the Iotx client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Aperi per se portam clientis Iotx in itineratore.  Hoc tantum effectivum est si itineratrum tuum supportat UPnP et id activum est.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>Designa portam utendo &amp;UPnP</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>&amp;IP vicarii:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;Porta:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Porta vicarii (e.g. 9050)</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Fenestra</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Monstra tantum iconem in tabella systematis postquam fenestram minifactam est.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;Minifac in tabellam systematis potius quam applicationum</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>M&amp;inifac ad claudendum</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>&amp;UI</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>&amp;Lingua monstranda utenti:</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>&amp;Unita qua quantitates monstrare:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Selige praedefinitam unitam subdivisionis monstrare in interfacie et quando nummos mittere</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancella</translation>
    </message>
    <message>
        <source>default</source>
        <translation>praedefinitum</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>Confirma optionum reconstituere</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>Inscriptio vicarii tradita non valida est.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Schema</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Iotx network after a connection is established, but this process has not completed yet.</source>
        <translation>Monstrata informatio fortasse non recentissima est.  Tuum cassidile per se synchronizat cum rete Iotx postquam conexio constabilita est, sed hoc actio nondum perfecta est.</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>Immatura:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>Fossum pendendum quod nondum maturum est</translation>
    </message>
    </context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>Quantitas</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    </context>
<context>
    <name>QObject::QObject</name>
    </context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>Versio clientis</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Informatio</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>Fenestra Debug</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>Tempus initiandi</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Rete</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>Numerus conexionum</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>Catena frustorum</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>Numerus frustorum iam nunc</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Hora postremi frusti</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Aperi</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;Terminale</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>Debug catalogi plica</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>Vacuefac terminale</translation>
    </message>
    <message>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>Utere sagittis sursum deorsumque ut per historiam naviges, et &lt;b&gt;Ctrl+L&lt;/b&gt; ut scrinium vacuefacias.</translation>
    </message>
    <message>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>Scribe &lt;b&gt;help&lt;/b&gt; pro summario possibilium mandatorum.</translation>
    </message>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>Quantitas:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Titulus:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>Nuntius:</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>Copy &amp;Address</source>
        <translation>&amp;Copia Inscriptionem</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Mitte Nummos</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>Inopia nummorum</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Quantitas:</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation>Transactionis merces:</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Mitte pluribus accipientibus simul</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>Adde &amp;Accipientem</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Vacuefac &amp;Omnia</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Pendendum:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Confirma actionem mittendi</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>&amp;Mitte</translation>
    </message>
    </context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>&amp;Quantitas:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>Pensa &amp;Ad:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Titulus:</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Glutina inscriptionem ex latibulo</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Nuntius:</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>Pensa Ad:</translation>
    </message>
    </context>
<context>
    <name>SendConfirmationDialog</name>
    </context>
<context>
    <name>ShutdownWindow</name>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Signationes - Signa / Verifica nuntium</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>&amp;Signa Nuntium</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Glutina inscriptionem ex latibulo</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Insere hic nuntium quod vis signare</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Signatio</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Copia signationem in latibulum systematis</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Iotx address</source>
        <translation>Signa nuntium ut demonstres hanc inscriptionem Iotx a te possessa esse</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>Signa &amp;Nuntium</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>Reconstitue omnes campos signandi nuntii</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Vacuefac &amp;Omnia</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>&amp;Verifica Nuntium</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Iotx address</source>
        <translation>Verifica nuntium ut cures signatum esse cum specifica inscriptione Iotx</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>Verifica &amp;Nuntium</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>Reconstitue omnes campos verificandi nuntii</translation>
    </message>
    </context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    </context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Haec tabula monstrat descriptionem verbosam transactionis</translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    </context>
<context>
    <name>TransactionView</name>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    </context>
<context>
    <name>WalletView</name>
    </context>
<context>
    <name>iotx-core</name>
    <message>
        <source>Options:</source>
        <translation>Optiones:</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Specifica indicem datorum</translation>
    </message>
    <message>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>Conecta ad nodum acceptare inscriptiones parium, et disconecte</translation>
    </message>
    <message>
        <source>Specify your own public address</source>
        <translation>Specifica tuam propriam publicam inscriptionem</translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Accipe terminalis et JSON-RPC mandata.</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Operare infere sicut daemon et mandata accipe</translation>
    </message>
    <message>
        <source>Iotx Core</source>
        <translation>Iotx Nucleus</translation>
    </message>
    <message>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation>Conglutina ad inscriptionem datam et semper in eam ausculta.  Utere [moderatrum]:porta notationem pro IPv6</translation>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation>Facere mandatum quotiescumque cassidilis transactio mutet (%s in mandato sbstituitur ab TxID)</translation>
    </message>
    <message>
        <source>Block creation options:</source>
        <translation>Optiones creandi frustorum:</translation>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation>Corruptum databasum frustorum invenitur</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>Visne reficere databasum frustorum iam?</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>Error initiando databasem frustorum</translation>
    </message>
    <message>
        <source>Error initializing wallet database environment %s!</source>
        <translation>Error initiando systematem databasi cassidilis %s!</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation>Error legendo frustorum databasem</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation>Error aperiendo databasum frustorum</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>Error: Inopia spatii disci!</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Non potuisse auscultare in ulla porta.  Utere -listen=0 si hoc vis.</translation>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation>Inopia descriptorum plicarum.</translation>
    </message>
    <message>
        <source>Verifying blocks...</source>
        <translation>Verificante frusta...</translation>
    </message>
    <message>
        <source>Verifying wallet...</source>
        <translation>Verificante cassidilem...</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Informatio</translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Mitte informationem vestigii/debug ad terminale potius quam plicam debug.log</translation>
    </message>
    <message>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>Diminue plicam debug.log ad initium clientis (praedefinitum: 1 nisi -debug)</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation>Signandum transactionis abortum est</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>Magnitudo transactionis nimis parva</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>Transactio nimis magna</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>Nomen utentis pro conexionibus JSON-RPC</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Monitio</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Tessera pro conexionibus JSON-RPC</translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation>Pelle mandatum quando optissimum frustum mutat (%s in mandato substituitur ab hash frusti)</translation>
    </message>
    <message>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>Permitte quaerenda DNS pro -addnode, -seednode, et -connect</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>Legens inscriptiones...</translation>
    </message>
    <message>
        <source>Invalid -proxy address: '%s'</source>
        <translation>Inscriptio -proxy non valida: '%s'</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: '%s'</source>
        <translation>Ignotum rete specificatum in -onlynet: '%s'</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>Inopia nummorum</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Legens indicem frustorum...</translation>
    </message>
    <message>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>Adice nodum cui conectere et conare sustinere conexionem apertam</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Legens cassidile...</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>Non posse cassidile regredi</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>Non posse scribere praedefinitam inscriptionem</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Iterum perlegens...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Completo lengendi</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
</context>
</TS>